// results.js — 扫描/分类/渲染/删除/文件树/缓存/停止
'use strict';

const $ = (id) => document.getElementById(id);
const tabBar = $('tabBar');
const resultArea = $('resultArea');
const subtitle = $('subtitle');
const scopeInput = $('scopeInput');
const btnScan = $('btnScan');
const btnExpandAll = $('btnExpandAll');
const btnCollapseAll = $('btnCollapseAll');
const btnSelectDefault = $('btnSelectDefault');
const btnClearSel = $('btnClearSel');
const btnDeleteSel = $('btnDeleteSel');
const btnCurrentDir = $('btnCurrentDir');
const btnWhole = $('btnWhole');
const btnPickFolder = $('btnPickFolder');
const progressWrap = $('progressWrap');
const progressBar = $('progressBar');
const progressText = $('progressText');

const urlParams = new URLSearchParams(location.search);
const tabId = parseInt(urlParams.get('tabId'), 10);

const CACHE_KEY = 'panCleaner_cache_v3';
let allFiles = [];
let categories = [];
let currentTab = null;
let currentScope = '/';
let scanning = false;
let scanAbort = false;
let fileTreeCache = {}; // path → [{name, path}]
let selectedTreePath = null;

// ========== 启动：验证 tabId + 缓存 ==========
document.addEventListener('DOMContentLoaded', async () => {
  // 验证 tabId 有效（必须存在且不是内部协议）
  const valid = await validateTabId(tabId);
  if (!valid) {
    await showTabPicker();
    return;
  }
  subtitle.textContent = '准备就绪';
  try {
    const cached = await chrome.storage.local.get(CACHE_KEY);
    if (cached[CACHE_KEY] && cached[CACHE_KEY].tabId === tabId) {
      const c = cached[CACHE_KEY];
      allFiles = c.allFiles;
      categories = c.categories;
      currentScope = c.scope || '/';
      scopeInput.value = currentScope;
      subtitle.textContent = `📦 使用缓存（${new Date(c.savedAt).toLocaleTimeString()}）· ${allFiles.length} 个文件 · 范围 ${currentScope}`;
      render();
      return;
    }
  } catch {}
  subtitle.textContent = '请选择范围后点扫描';
});

async function validateTabId(id) {
  if (!id) return false;
  try {
    const tab = await chrome.tabs.get(id);
    if (!tab) return false;
    if (tab.url && ['chrome://', 'edge://', 'chrome-extension://', 'edge-extension://', 'about:'].some((p) => tab.url.startsWith(p))) return false;
    return true;
  } catch { return false; }
}

async function showTabPicker() {
  const tabs = await chrome.tabs.query({});
  const usable = tabs.filter((t) => t.url && !['chrome://', 'edge://', 'chrome-extension://', 'edge-extension://', 'about:'].some((p) => t.url.startsWith(p)));
  // 优先排 pan.baidu.com 到前面
  usable.sort((a, b) => (a.url.includes('pan.baidu.com') ? -1 : 1) - (b.url.includes('pan.baidu.com') ? -1 : 1));

  resultArea.innerHTML = `
    <div class="empty">
      <div class="big">🌐</div>
      <div style="font-weight:600;margin-bottom:8px">请选择百度网盘所在的标签页</div>
      <div style="font-size:12px;color:#94a3b8;margin-bottom:16px">找不到原来的标签页了，请选一个已打开 pan.baidu.com 的标签页</div>
      <div id="tabList" style="display:flex;flex-direction:column;gap:6px;max-height:320px;overflow-y:auto;max-width:700px;margin:0 auto;text-align:left"></div>
    </div>`;
  const list = document.getElementById('tabList');
  if (!usable.length) {
    list.innerHTML = '<div style="color:#dc2626">没有找到可用的网页标签页。请先打开 pan.baidu.com。</div>';
    return;
  }
  for (const t of usable) {
    const row = document.createElement('div');
    row.style.cssText = 'padding:10px 12px;background:#f8fafc;border-radius:8px;cursor:pointer;border:1px solid #e2e8f0;display:flex;align-items:center;gap:10px;font-size:12px';
    const favIcon = t.favIconUrl ? `<img src="${t.favIconUrl}" width="16" height="16">` : '';
    const isPan = t.url.includes('pan.baidu.com');
    row.innerHTML = `${favIcon}<div style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><b>${isPan ? '🟢 ' : ''}${t.title || ''}</b><div style="color:#94a3b8;font-size:11px">${t.url}</div></div>`;
    row.onclick = () => { location.href = location.origin + location.pathname + '?tabId=' + t.id; };
    list.appendChild(row);
  }
}

// ========== 扫描 ==========
btnScan.addEventListener('click', () => {
  if (!scanning) {
    // 开始
    currentScope = scopeInput.value.trim() || '/';
    startScan(currentScope);
  } else {
    // 停止
    stopScan();
  }
});

async function startScan(rootDir) {
  scanning = true;
  scanAbort = false;
  btnScan.textContent = '⏹️ 停止扫描';
  btnScan.className = 'btn-stop';
  progressWrap.style.display = 'block';
  progressBar.style.width = '0%';
  progressText.textContent = `扫描中 ${rootDir}... 注入 content script...`;
  subtitle.textContent = `扫描中 ${rootDir}...`;

  // 注入 content.js（如果页面还没有）
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content.js']
    });
  } catch (e) {
    // 可能已注入，忽略
  }

  // 设置中止标记（页面级，立即生效）
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      func: () => { try { window._scanAbort = false; } catch {} }
    });
  } catch {}

  // 先列出总数预估
  progressText.textContent = '扫描中...';

  // 监听 progress/done/error 消息
  const msgHandler = (msg, sender, sendResponse) => {
    if (sender.tab && sender.tab.id !== tabId) return;
    if (msg.type === 'scanProgress') {
      if (msg._debug) {
        progressText.innerHTML = `<b>🔍 诊断信息：</b><br>✓ Cookie BDUSS: <b style="color:${msg.hasBDUSS?'#16a34a':'#dc2626'}">${msg.hasBDUSS?'存在':'缺失'}</b><br>✓ bdstoken: <b style="color:${msg.bdstokenLen>0?'#16a34a':'#dc2626'}">${msg.bdstokenLen>0?'找到 ('+msg.bdstokenLen+' 字符)':'没找到'}</b><br>📡 请求: ${msg.url}<br>🔄 已扫描 ${msg.scanned} 个文件...`;
      } else {
        progressText.textContent = `扫描中 ${msg.scanned} 个文件...`;
        const pct = msg.total ? Math.min(95, Math.round(msg.scanned / msg.total * 100)) : 50;
        progressBar.style.width = pct + '%';
      }
    } else if (msg.type === 'scanDone') {
      chrome.runtime.onMessage.removeListener(msgHandler);
      finishScan(msg.files, msg.rootDir, false);
    } else if (msg.type === 'scanError') {
      chrome.runtime.onMessage.removeListener(msgHandler);
      finishScan([], rootDir, true, msg.error);
    }
  };
  chrome.runtime.onMessage.addListener(msgHandler);

  // 发起扫描
  chrome.tabs.sendMessage(tabId, { action: 'listAllFiles', rootDir }, (resp) => {
    if (chrome.runtime.lastError) {
      // 如果没回，可能 content.js 没收到。等 scanDone 消息来兜底
    }
  });
}

function stopScan() {
  scanAbort = true;
  try {
    chrome.scripting.executeScript({
      target: { tabId },
      func: () => { try { window._scanAbort = true; } catch {} }
    });
  } catch {}
  progressText.textContent += '（已请求停止，等待中断...）';
}

function finishScan(files, rootDir, err, errMsg) {
  scanning = false;
  btnScan.textContent = '🔍 按此范围扫描';
  btnScan.className = 'btn-scan';
  progressWrap.style.display = 'none';

  if (err) {
    subtitle.textContent = '❌ 扫描失败: ' + errMsg;
    return;
  }
  if (!files || files.length === 0) {
    subtitle.textContent = '⚠️ 没扫到文件，请检查范围或登录状态';
    return;
  }
  allFiles = files;
  categories = window.Finder.findDuplicatesByCategory(allFiles);
  currentScope = rootDir;
  subtitle.textContent = scanAbort
    ? `⏹️ 已停止 · 部分扫描 ${allFiles.length} 个文件 · 范围 ${rootDir}`
    : `✅ 扫描完成 · ${allFiles.length} 个文件 · 范围 ${rootDir}`;
  saveCache();
  render();
}

async function saveCache() {
  try {
    await chrome.storage.local.set({
      [CACHE_KEY]: { tabId, allFiles, categories, scope: currentScope, savedAt: Date.now() }
    });
  } catch {}
}

// ========== 渲染 Tab + 结果 ==========
function render() {
  tabBar.innerHTML = '';
  resultArea.innerHTML = '';
  if (!categories.length) return;

  for (const cat of categories) {
    const btn = document.createElement('div');
    btn.className = 'tab' + (cat.groupCount > 0 ? '' : '');
    btn.innerHTML = `${cat.label}<span class="badge">${cat.dupCount ? cat.dupCount + '个重复' : '无重复'}</span>`;
    btn.addEventListener('click', () => { currentTab = cat.key; renderTabContent(); document.querySelectorAll('.tab').forEach(t => t.classList.remove('active')); btn.classList.add('active'); });
    tabBar.appendChild(btn);
  }

  // 默认选第一个有重复的
  const firstDup = categories.find(c => c.groupCount > 0) || categories[0];
  currentTab = firstDup.key;
  document.querySelectorAll('.tab')[categories.findIndex(c => c.key === firstDup.key)].classList.add('active');
  renderTabContent();
}

function renderTabContent() {
  resultArea.innerHTML = '';
  const cat = categories.find(c => c.key === currentTab);
  if (!cat) return;

  if (!cat.dupGroups.length) {
    resultArea.innerHTML = `<div class="empty"><div class="big">🎉</div>「${cat.label}」没有重复文件！</div>`;
    updateDeleteBtn();
    return;
  }

  for (const group of cat.dupGroups) {
    const d = document.createElement('div');
    d.className = 'dup-group open';
    const sizeLabel = window.Finder.formatSize(group.size);
    const hk = (group.files[0].path || '').substring((group.files[0].path || '').lastIndexOf('/') + 1);
    d.innerHTML = `
      <div class="dup-hd">
        <div class="dup-title"><span class="chev">▶</span> ${sizeLabel} · ${hk}<span class="dup-meta">${group.files.length} 个副本${group.md5 ? ' · md5:' + group.md5.substring(0,8) : ''}</span></div>
      </div>
      <div class="dup-body"></div>`;
    const body = d.querySelector('.dup-body');
    // 默认勾选重复的（保留第一个）
    group.files.forEach((f, i) => {
      const row = document.createElement('div');
      row.className = 'file-row' + (i === 0 ? ' keep' : '');
      const checked = i !== 0;
      row.innerHTML = `
        <input type="checkbox" data-fs="${f.fs_id}" data-path="${f.path}" ${checked ? 'checked' : ''}>
        <span class="path" title="${f.path}">${f.path}</span>
        <span class="size">${window.Finder.formatSize(f.size)}</span>`;
      body.appendChild(row);
    });
    d.querySelector('.dup-hd').addEventListener('click', (e) => {
      if (e.target.tagName === 'INPUT') return;
      d.classList.toggle('open');
    });
    resultArea.appendChild(d);
  }
  // 事件委托
  resultArea.addEventListener('change', (e) => { if (e.target.tagName === 'INPUT') updateDeleteBtn(); });
  updateDeleteBtn();
}

function updateDeleteBtn() {
  const cbs = resultArea.querySelectorAll('input[type=checkbox]:checked');
  btnDeleteSel.disabled = cbs.length === 0;
  btnDeleteSel.textContent = `🗑️ 删除已勾选 (${cbs.length})`;
}

// ========== 工具按钮 ==========
btnExpandAll.addEventListener('click', () => document.querySelectorAll('.dup-group').forEach(g => g.classList.add('open')));
btnCollapseAll.addEventListener('click', () => document.querySelectorAll('.dup-group').forEach(g => g.classList.remove('open')));
btnSelectDefault.addEventListener('click', () => {
  document.querySelectorAll('.dup-group').forEach(g => {
    const cbs = g.querySelectorAll('input[type=checkbox]');
    cbs.forEach((cb, i) => { cb.checked = i !== 0; });
  });
  updateDeleteBtn();
});
btnClearSel.addEventListener('click', () => {
  document.querySelectorAll('.dup-group input[type=checkbox]').forEach(cb => cb.checked = false);
  updateDeleteBtn();
});

// 当前文件夹 / 整个网盘
btnCurrentDir.addEventListener('click', async () => {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  } catch {}
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { action: 'getCurrentBrowseDir' });
    if (resp && resp.dir) { scopeInput.value = resp.dir; currentScope = resp.dir; }
  } catch { scopeInput.value = '/'; }
});
btnWhole.addEventListener('click', () => { scopeInput.value = '/'; currentScope = '/'; });

// 删除
btnDeleteSel.addEventListener('click', async () => {
  const cbs = resultArea.querySelectorAll('input[type=checkbox]:checked');
  if (!cbs.length) return;
  if (!confirm(`确定删除 ${cbs.length} 个文件？此操作不可恢复！`)) return;
  const ids = Array.from(cbs).map(c => parseInt(c.dataset.fs, 10));
  btnDeleteSel.disabled = true; btnDeleteSel.textContent = '删除中...';
  try {
    const resp = await chrome.tabs.sendMessage(tabId, { action: 'deleteFiles', ids });
    if (resp && resp.ok) {
      alert(`✓ 已删除 ${resp.deleted} 个文件\n现在重新扫描...`);
      startScan(currentScope); // 重扫
    } else {
      alert('删除失败: ' + (resp && resp.error || '未知原因'));
    }
  } catch (e) {
    alert('删除出错: ' + e.message);
  }
});

// ========== 文件树弹窗 ==========
btnPickFolder.addEventListener('click', openFileTree);

async function openFileTree() {
  // 先确保 content.js 注入到 pan.baidu.com 页面
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  } catch {}
  // 验证一下注入成功
  try {
    const pong = await chrome.tabs.sendMessage(tabId, { action: 'checkLogin' });
    if (!pong || typeof pong.loggedIn === 'undefined') {
      alert('内容脚本未响应。请确认已打开 pan.baidu.com 并登录，然后刷新本页面重试。');
      return;
    }
  } catch (e) {
    alert('无法连接到 pan.baidu.com 页面。请确认当前标签页是 pan.baidu.com 且已登录。\n\n详情：' + e.message);
    return;
  }
  selectedTreePath = null;
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `
    <div class="modal">
      <div class="modal-hd">📁 选择文件夹 <span class="close">×</span></div>
      <div class="modal-body" id="treeRoot"></div>
      <div class="modal-ft">
        <div class="cur" id="treeCur">当前：—</div>
        <div>
          <button class="btn-ghost" id="treeCancel">取消</button>
          <button class="btn-ghost" id="treePick">确定</button>
          <button class="btn-scan" id="treeGo">✅ 确定并扫描</button>
        </div>
      </div>
    </div>`;
  document.body.appendChild(bg);
  bg.querySelector('.close').onclick = () => bg.remove();
  bg.querySelector('#treeCancel').onclick = () => bg.remove();
  bg.querySelector('#treePick').onclick = () => { if (selectedTreePath) { scopeInput.value = selectedTreePath; currentScope = selectedTreePath; bg.remove(); } };
  bg.querySelector('#treeGo').onclick = () => {
    if (selectedTreePath) { scopeInput.value = selectedTreePath; currentScope = selectedTreePath; bg.remove(); startScan(currentScope); }
  };

  const root = bg.querySelector('#treeRoot');
  // 根节点
  const rootRow = document.createElement('div');
  rootRow.className = 'tree-row';
  rootRow.innerHTML = `<span class="arrow">▶</span>📁 整个网盘`;
  const rootChildren = document.createElement('div');
  rootChildren.className = 'tree-children';
  const loading = document.createElement('div');
  loading.className = 'tree-loading'; loading.textContent = '加载中...';
  rootChildren.appendChild(loading);
  root.appendChild(rootChildren);
  rootRow.onclick = async (e) => {
    e.stopPropagation();
    if (selectedTreePath === '/') return;
    selectedTreePath = '/';
    bg.querySelector('#treeCur').textContent = '当前：📁 整个网盘 (/)';
    selectRow(rootRow);
    if (rootRow.dataset.loaded === '1') return;
    rootRow.dataset.loaded = '1';
    await loadSubDirs(rootChildren, '/');
    rootRow.querySelector('.arrow').textContent = '▼';
  };
  root.appendChild(rootRow);

  function selectRow(r) { document.querySelectorAll('#treeRoot .tree-row').forEach(x => x.classList.remove('selected')); r.classList.add('selected'); }
}

async function loadSubDirs(container, path) {
  container.innerHTML = '';
  let dirs = [];
  if (fileTreeCache[path]) {
    dirs = fileTreeCache[path];
  } else {
    try {
      const resp = await chrome.tabs.sendMessage(tabId, { action: 'listSubDirs', path });
      if (resp && resp.error) throw new Error(resp.error);
      dirs = (resp && resp.dirs) || [];
    } catch (e) {
      const errBox = document.createElement('div');
      errBox.className = 'tree-loading';
      errBox.style.color = '#dc2626';
      errBox.textContent = '❌ 加载失败: ' + (e.message || '未知错误');
      container.appendChild(errBox);
      fileTreeCache[path] = [];
      return;
    }
    fileTreeCache[path] = dirs;
  }
  if (!dirs.length) {
    const e = document.createElement('div'); e.className = 'tree-loading'; e.textContent = '（没有子文件夹）';
    container.appendChild(e); return;
  }
  for (const d of dirs) {
    const node = document.createElement('div');
    node.className = 'tree-node';
    const row = document.createElement('div');
    row.className = 'tree-row';
    row.innerHTML = `<span class="arrow">▶</span>📁 ${d.name}`;
    const children = document.createElement('div');
    children.className = 'tree-children';
    row.onclick = async (e) => {
      e.stopPropagation();
      selectedTreePath = d.path;
      const modal = row.closest('.modal-bg');
      modal.querySelector('#treeCur').textContent = `当前：📁 ${d.name} (${d.path})`;
      const allRows = modal.querySelectorAll('.tree-row');
      allRows.forEach(r => r.classList.remove('selected'));
      row.classList.add('selected');
      if (row.dataset.loaded === '1') return;
      row.dataset.loaded = '1';
      row.querySelector('.arrow').textContent = '▼';
      await loadSubDirs(children, d.path);
    };
    node.appendChild(row);
    node.appendChild(children);
    container.appendChild(node);
  }
}
