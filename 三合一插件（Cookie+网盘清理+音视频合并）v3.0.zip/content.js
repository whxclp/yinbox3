// content.js — 注入到 pan.baidu.com 的内容脚本 v3
// 跑在同源页面上下文，fetch 自动带 HttpOnly Cookie
(function () {
  'use strict';

  // ============ 版本标记 + 防重复注入 ============
  const VER = 3;
  const KEY = '__panCleanerContentVer';

  // 旧版残留？发消息请它自杀
  try {
    chrome.runtime.sendMessage({ type: 'ping' }, () => {});
  } catch {}

  // 如果已经有更新的版本在跑，自杀
  try {
    if (window[KEY] && window[KEY] >= VER) return;
  } catch {}
  window[KEY] = VER;

  // ============ 安全调用 chrome.runtime 包装 ============
  function safeSendMessage(msg) {
    try { chrome.runtime.sendMessage(msg); } catch { /* Extension context invalidated — 忽略 */ }
  }

  // ============ 消息路由 ============
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    // context 已失效？不响应
    try { if (!chrome.runtime.id) return; } catch { return; }

    if (msg.action === 'checkLogin') {
      sendResponse({ loggedIn: checkLogin(), ver: VER });
    }
    else if (msg.action === 'listAllFiles') {
      const rootDir = msg.rootDir || '/';
      listAllFiles(null, rootDir).then((result) => {
        safeSendMessage({ type: 'scanDone', files: result.files, rootDir, aborted: result.aborted });
      }).catch((err) => {
        safeSendMessage({ type: 'scanError', error: err.message });
      });
      sendResponse({ started: true, ver: VER });
    }
    else if (msg.action === 'listSubDirs') {
      listSubDirs(msg.path || '/').then((dirs) => sendResponse({ dirs })).catch((e) => sendResponse({ dirs: [], error: e.message }));
      return true;
    }
    else if (msg.action === 'getCurrentBrowseDir') {
      sendResponse({ dir: getCurrentBrowseDir() });
    }
    else if (msg.action === 'deleteFiles') {
      deleteFiles(msg.ids || []).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: e.message }));
      return true;
    }
    else if (msg.action === 'getBDSToken') {
      sendResponse({ token: getBdstoken() });
    }
  });

  // ============ 登录检查 ============
  function checkLogin() {
    try { const cookie = document.cookie; return cookie.includes('BDUSS='); } catch { return false; }
  }

  function getBdstoken() {
    try { if (window.bdstoken) return window.bdstoken; } catch {}
    try { if (window.__INITIAL_STATE__ && window.__INITIAL_STATE__.bdstoken) return window.__INITIAL_STATE__.bdstoken; } catch {}
    try { if (window.__INITIAL_STATE__ && window.__INITIAL_STATE__.userinfo && window.__INITIAL_STATE__.userinfo.bdstoken) return window.__INITIAL_STATE__.userinfo.bdstoken; } catch {}
    try {
      const scripts = document.querySelectorAll('script');
      for (const s of scripts) {
        const t = s.textContent;
        let m = t && t.match(/"bdstoken"\s*:\s*"([^"]+)"/);
        if (m) return m[1];
        m = t && t.match(/bdstoken\s*=\s*"([^"]+)"/);
        if (m) return m[1];
      }
    } catch {}
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.toLowerCase().includes('bdstoken')) {
          const v = localStorage.getItem(k);
          if (v) return v;
        }
      }
    } catch {}
    try {
      const m = document.cookie.match(/STOKEN=([^;]+)/i);
      if (m) return m[1];
    } catch {}
    return '';
  }

  function getCurrentBrowseDir() {
    try {
      const hash = location.hash;
      const m = hash.match(/path=([^&]+)/);
      if (m) return decodeURIComponent(m[1]);
    } catch {}
    try {
      const sp = new URLSearchParams(location.search);
      const p = sp.get('path');
      if (p) return p;
    } catch {}
    return '/';
  }

  // ============ 文件递归列表 ============
  async function listAllFiles(onProgress, rootDir = '/') {
    const allFiles = [];
    let scannedCount = 0;
    let totalEstimate = 0;

    async function fetchPage(dir, start = 0) {
      const bdstoken = getBdstoken();
      const hasBDUSS = (function () { try { return document.cookie.includes('BDUSS='); } catch { return false; } })();
      // 新版 API：/rest/2.0/xpan/file?method=list
      const qs = new URLSearchParams({
        method: 'list', dir: dir, order: 'name', desc: '0', start: String(start), limit: '1000',
        web: '1', app_id: '250528', channel: 'chunlei', clienttype: '0',
      });
      if (bdstoken) qs.set('bdstoken', bdstoken);
      const url = `https://pan.baidu.com/rest/2.0/xpan/file?${qs.toString()}`;

      // ===== 诊断：F12 控制台里直接看 =====
      console.log('%c[网盘清理 诊断]', 'background:#ec4899;color:#fff;padding:2px 6px;border-radius:4px;font-weight:bold');
      console.log('  Cookie BDUSS:', hasBDUSS ? '✅ 存在' : '❌ 缺失');
      console.log('  bdstoken:', bdstoken ? `✅ 找到 (${bdstoken.length}字符)` : '❌ 没找到');
      console.log('  请求 URL:', url.replace(bdstoken, '[TOKEN]'));
      const resp = await fetch(url, { credentials: 'include' });
      console.log('  HTTP 状态:', resp.status);
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const text = await resp.text();
      console.log('  响应内容:', text.substring(0, 500));
      let data;
      try { data = JSON.parse(text); } catch {
        throw new Error(`响应非 JSON: ${text.substring(0, 200)}`);
      }
      if (data.errno !== 0) {
        safeSendMessage({ type: 'scanError', error: `errno=${data.errno} (${data.errmsg || '无 errmsg'})` + ` | bduss=${hasBDUSS} bdstoken_len=${(bdstoken||'').length}` });
        throw new Error(`API errno=${data.errno}${data.errmsg ? ' (' + data.errmsg + ')' : ''}`);
      }
      return data;
    }

    async function walk(dir) {
      try { if (window._scanAbort) return; } catch {}
      let start = 0;
      while (true) {
        try { if (window._scanAbort) return; } catch {}
        const data = await fetchPage(dir, start);
        const list = data.list || [];
        if (start === 0) totalEstimate += (data.file_count || list.length);
        for (const item of list) {
          try { if (window._scanAbort) return; } catch {}
          scannedCount++;
          if (onProgress) onProgress(null, scannedCount, totalEstimate);
          safeSendMessage({ type: 'scanProgress', scanned: scannedCount, total: totalEstimate });
          if (item.isdir === 1) {
            await walk(item.path);
          } else {
            allFiles.push({
              fs_id: item.fs_id, path: item.path,
              server_filename: item.server_filename,
              size: item.size, md5: item.md5 || '', isdir: 0,
            });
          }
        }
        if (list.length < 1000) break;
        start += 1000;
      }
    }

    await walk(rootDir);
    return { files: allFiles, scannedCount, totalEstimate, aborted: !!window._scanAbort };
  }

  // ============ 子目录列表（文件树） ============
  async function listSubDirs(path = '/') {
    const bdstoken = getBdstoken();
    const qs = new URLSearchParams({
      method: 'list', dir: path, order: 'name', desc: '0', start: '0', limit: '1000',
      web: '1', app_id: '250528', channel: 'chunlei', clienttype: '0',
    });
    if (bdstoken) qs.set('bdstoken', bdstoken);
    const url = `https://pan.baidu.com/rest/2.0/xpan/file?${qs.toString()}`;
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    if (data.errno !== 0) throw new Error(`errno=${data.errno}${data.errmsg ? ' (' + data.errmsg + ')' : ''}`);
    return (data.list || []).filter((i) => i.isdir === 1).map((d) => ({ path: d.path, name: d.server_filename }));
  }

  // ============ 删除 ============
  async function deleteFiles(ids) {
    if (!ids.length) return { ok: true, deleted: 0 };
    const bdstoken = getBdstoken();
    const url = `https://pan.baidu.com/api/filemanager?opera=delete&async=1&bdstoken=${bdstoken}&web=1&app_id=250528&channel=chunlei&clienttype=0`;
    const resp = await fetch(url, {
      method: 'POST', credentials: 'include',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      body: 'filelist=' + encodeURIComponent(JSON.stringify(ids)),
    });
    const data = await resp.json();
    if (data.errno !== 0) throw new Error(`删除失败 errno=${data.errno}${data.errmsg ? ' (' + data.errmsg + ')' : ''}`);
    return { ok: true, deleted: ids.length };
  }
})();
