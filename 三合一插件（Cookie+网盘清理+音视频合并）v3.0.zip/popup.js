// popup.js — 三合一 popup 逻辑
// 卡片点击统一用 data-action 分发
const $ = (id) => document.getElementById(id);
const cookiePanel = $('cookiePanel');
const btnGetCookie = $('btnGetCookie');
const btnCopyCookie = $('btnCopyCookie');
const cookieStatus = $('cookieStatus');
let lastCookieStr = '';

// 卡片点击事件
document.querySelectorAll('.card').forEach((card) => {
  card.addEventListener('click', () => {
    const action = card.dataset.action;
    handleAction(action, card);
  });
});

function handleAction(action, card) {
  // 不能注入的协议
  const INTERNAL_PREFIXES = ['chrome://', 'edge://', 'about:', 'chrome-extension://', 'edge-extension://'];
  function isInternalUrl(url) {
    if (!url) return true;
    return INTERNAL_PREFIXES.some((p) => url.startsWith(p));
  }

  if (action === 'cookie') {
    // 切面板
    document.querySelectorAll('.card').forEach((c) => (c.dataset.active = 'false'));
    const show = cookiePanel.style.display === 'none';
    cookiePanel.style.display = show ? 'block' : 'none';
    card.dataset.active = show ? 'true' : 'false';
  }

  else if (action === 'clean') {
    // 找一个 pan.baidu.com 的 tab，找不到就用当前 tab
    chrome.tabs.query({}, async (allTabs) => {
      // 优先找 pan.baidu.com
      let targetTab = allTabs.find((t) => t.url && t.url.includes('pan.baidu.com'));
      if (!targetTab) {
        // 没有就找当前活动 tab（非内部协议）
        targetTab = allTabs.find((t) => t.active && !isInternalUrl(t.url));
      }
      if (!targetTab) {
        alert('请先打开 pan.baidu.com 并登录，然后再点清理。\n（必须有一个普通网页标签页）');
        return;
      }
      const url = new URL(chrome.runtime.getURL('results.html'));
      url.searchParams.set('tabId', targetTab.id);
      chrome.tabs.create({ url: url.toString() });
      window.close();
    });
  }

  else if (action === 'merge') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab) { alert('没有当前标签页'); return; }
      if (isInternalUrl(tab.url)) {
        alert('请先打开一个普通网页（如任意文章页、视频页等），然后再点合并。\n当前页面不允许注入脚本。');
        return;
      }
      try {
        await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['merge.js'] });
        await new Promise((r) => setTimeout(r, 300));
        const res = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            if (typeof window.openMergePanel === 'function') {
              try { window.openMergePanel(); return { ok: true }; }
              catch (e) { return { ok: false, err: e.message }; }
            }
            return { ok: false, err: 'window.openMergePanel 不存在（merge.js 可能未初始化）' };
          }
        });
        const r = res[0].result;
        if (!r.ok) { alert('合并面板打开失败: ' + (r.err || '未知原因')); }
        window.close();
      } catch (e) {
        alert('注入失败: ' + e.message + '\n请先打开一个普通网页再试。');
      }
    });
  }
}

// Cookie 功能
btnGetCookie.addEventListener('click', () => {
  cookieStatus.className = '';
  cookieStatus.textContent = '获取中...';
  cookieStatus.classList.add('show');
  btnGetCookie.disabled = true;

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab) {
      cookieStatus.textContent = '没有当前标签页';
      btnGetCookie.disabled = false;
      return;
    }
    try {
      const url = new URL(tab.url);
      chrome.cookies.getAll({ domain: url.hostname }, (cookies) => {
        btnGetCookie.disabled = false;
        if (!cookies || cookies.length === 0) {
          cookieStatus.textContent = `域名 ${url.hostname} 下没找到 Cookie\n尝试了 hostname: ${url.hostname}`;
          return;
        }
        const str = cookies.map((c) => `${c.name}=${c.value}`).join('; ');
        lastCookieStr = str;
        btnCopyCookie.disabled = false;
        cookieStatus.textContent = `✓ 找到 ${cookies.length} 个 Cookie\n域名: ${url.hostname}\n点「复制」按钮复制全部`;
      });
    } catch (e) {
      btnGetCookie.disabled = false;
      cookieStatus.textContent = 'URL 解析失败: ' + e.message;
    }
  });
});

btnCopyCookie.addEventListener('click', async () => {
  if (!lastCookieStr) return;
  try {
    await navigator.clipboard.writeText(lastCookieStr);
    btnCopyCookie.textContent = '已复制 ✓';
    setTimeout(() => (btnCopyCookie.textContent = '复制'), 1500);
  } catch (e) {
    // 降级方案
    const ta = document.createElement('textarea');
    ta.value = lastCookieStr;
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); btnCopyCookie.textContent = '已复制 ✓'; setTimeout(() => btnCopyCookie.textContent = '复制', 1500); }
    catch (_) { alert('复制失败，请手动选中 cookieStatus 里的文本复制'); }
    document.body.removeChild(ta);
  }
});
