// finder.js — 百度网盘重复文件检测 + 分类
(function () {
  'use strict';

  // 7 类：视频/图片/音频/文档/压缩包/代码/其他
  const CATEGORIES = {
    video: { label: '🎬 视频', exts: ['mp4','mkv','avi','mov','wmv','flv','rmvb','m4v','ts','webm','f4v','3gp'] },
    image: { label: '🖼️ 图片', exts: ['jpg','jpeg','png','gif','bmp','webp','tiff','ico','heic','svg'] },
    audio: { label: '🎵 音频', exts: ['mp3','wav','flac','aac','ogg','m4a','wma','ape','alac'] },
    doc:   { label: '📄 文档', exts: ['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','md','rtf','epub','mobi','csv'] },
    archive:{label: '📦 压缩包', exts: ['zip','rar','7z','tar','gz','bz2','xz','iso'] },
    code:  { label: '💻 代码', exts: ['py','js','ts','java','c','cpp','cs','go','rs','rb','php','html','css','json','xml','yml','sh','bat','sql'] },
  };

  function classify(filename) {
    const lower = filename.toLowerCase();
    const dot = lower.lastIndexOf('.');
    if (dot === -1) return 'other';
    const ext = lower.substring(dot + 1);
    for (const [key, cfg] of Object.entries(CATEGORIES)) {
      if (cfg.exts.includes(ext)) return key;
    }
    return 'other';
  }

  function findDuplicatesByCategory(allFiles) {
    // 先按分类
    const grouped = {};
    for (const key of Object.keys(CATEGORIES)) grouped[key] = [];
    grouped.other = [];

    for (const f of allFiles) {
      const cat = classify(f.server_filename || f.path);
      grouped[cat].push(f);
    }

    // 每类内按 size 分组 → 同 size 的再看 md5（有 md5 直接用，没有就只能同 size 粗判）
    const result = [];
    const catOrder = ['video','image','audio','doc','archive','code','other'];
    for (const catKey of catOrder) {
      const files = grouped[catKey] || [];
      // 按 size 分组
      const bySize = {};
      for (const f of files) {
        const sz = f.size || 0;
        (bySize[sz] = bySize[sz] || []).push(f);
      }
      // 每组内按 md5（如果有）二次分组
      const dupGroups = [];
      for (const [sz, arr] of Object.entries(bySize)) {
        if (arr.length < 2) continue;
        const withMd5 = arr.filter((f) => f.md5 && f.md5.length >= 16);
        const withoutMd5 = arr.filter((f) => !f.md5 || f.md5.length < 16);
        // 有 md5 的按 md5 分
        const byMd5 = {};
        for (const f of withMd5) (byMd5[f.md5] = byMd5[f.md5] || []).push(f);
        for (const [md5, g] of Object.entries(byMd5)) {
          if (g.length >= 2) dupGroups.push({ size: Number(sz), md5, files: g });
        }
        // 没 md5 的：同 size ≥ 2 也归为一组（保守）
        if (withoutMd5.length >= 2) {
          dupGroups.push({ size: Number(sz), md5: '', files: withoutMd5 });
        }
      }
      // 按重复文件数量降序
      dupGroups.sort((a, b) => b.files.length - a.files.length);
      result.push({
        key: catKey,
        label: CATEGORIES[catKey] ? CATEGORIES[catKey].label : '📁 其他',
        total: files.length,
        dupCount: dupGroups.reduce((s, g) => s + g.files.length, 0),
        groupCount: dupGroups.length,
        dupGroups,
      });
    }
    return result;
  }

  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
  }

  // 暴露到全局
  window.Finder = { findDuplicatesByCategory, classify, formatSize, CATEGORIES };
})();
