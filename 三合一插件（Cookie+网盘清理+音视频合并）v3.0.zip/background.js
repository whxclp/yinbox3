// background.js — service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('三合一扩展已安装');
});

// 处理来自 results.html 的 getCurrentBrowseDir 消息时需要知道目标 tabId
// 这里只做转发，实际逻辑在 content.js
