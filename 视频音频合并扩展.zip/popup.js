/* 视频音频合并 —— 浏览器扩展弹窗逻辑
 * 纯本地合成：视频文件 + 音频文件 -> 完整 mp4（不转码，保留 B 帧）
 * 依赖同目录下的 mediabunny.js（纯 JS 音视频封装库）
 */
(function () {
  "use strict";

  var MB = globalThis.Mediabunny;
  if (!MB || typeof MB.Input !== "function") {
    document.body.innerHTML = '<div style="padding:20px;color:#b42318">合并组件加载失败，请重新加载扩展。</div>';
    return;
  }

  var $ = function (sel) { return document.querySelector(sel); };

  var $drop = $("[data-drop]");
  var $vname = $("[data-vname]");
  var $aname = $("[data-aname]");
  var $bar = $("[data-bar]");
  var $text = $("[data-text]");
  var $toast = $("[data-toast]");

  var videoFile = null;
  var audioFile = null;
  var merging = false;
  var toastTimer = null;

  function toast(msg, type) {
    if (!$toast) return;
    $toast.textContent = msg;
    $toast.className = "toast show" + (type ? " " + type : "");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { $toast.className = "toast"; }, 3200);
  }

  function setProgress(percent, text) {
    if ($bar && typeof percent === "number") $bar.style.width = Math.max(0, Math.min(100, percent)) + "%";
    if ($text && text) $text.textContent = text;
  }

  function setLabel(kind, file) {
    var el = kind === "video" ? $vname : $aname;
    if (!el) return;
    el.textContent = file ? file.name : "未选择";
    el.title = file ? file.name : "";
  }

  function guessKindByName(name) {
    var n = (name || "").toLowerCase();
    if (/_audio|_音频|音频/.test(n) || /\.(m4a|aac|mp3|ogg|oga|opus|flac|wav|wma)$/.test(n)) return "audio";
    if (/_video|_视频|视频/.test(n) || /\.(m4v|webm|mkv|flv|ts|mov|avi)$/.test(n)) return "video";
    return null;
  }

  async function probeFileKind(file) {
    try {
      var buf = await file.arrayBuffer();
      var input = new MB.Input({ source: new MB.BufferSource(new Uint8Array(buf)), formats: MB.ALL_FORMATS });
      var vTrack = await input.getPrimaryVideoTrack();
      return vTrack ? "video" : "audio";
    } catch (e) {
      return guessKindByName(file.name);
    }
  }

  // 纯 JS 转封装合并：视频 + 音频 -> 完整 mp4
  async function mergeMediaBuffers(videoData, audioData) {
    var vInput = new MB.Input({ source: new MB.BufferSource(videoData), formats: MB.ALL_FORMATS });
    var vTrack = await vInput.getPrimaryVideoTrack();
    if (!vTrack) throw new Error("视频文件里没有找到画面轨道");
    var vDecCfg = await vTrack.getDecoderConfig();

    var aInput = new MB.Input({ source: new MB.BufferSource(audioData), formats: MB.ALL_FORMATS });
    var aTrack = await aInput.getPrimaryAudioTrack();
    if (!aTrack) throw new Error("音频文件里没有找到声音轨道");
    var aDecCfg = await aTrack.getDecoderConfig();

    var output = new MB.Output({
      format: new MB.Mp4OutputFormat({ fastStart: "in-memory" }),
      target: new MB.BufferTarget()
    });
    var vSource = new MB.EncodedVideoPacketSource(vTrack.codec);
    output.addVideoTrack(vSource);
    var aSource = new MB.EncodedAudioPacketSource(aTrack.codec);
    output.addAudioTrack(aSource);
    await output.start();

    var i = 0;
    for await (var packet of new MB.EncodedPacketSink(vTrack).packets()) {
      await vSource.add(packet, i === 0 ? { decoderConfig: vDecCfg } : undefined);
      i++;
    }
    i = 0;
    for await (var packet of new MB.EncodedPacketSink(aTrack).packets()) {
      await aSource.add(packet, i === 0 ? { decoderConfig: aDecCfg } : undefined);
      i++;
    }

    await output.finalize();
    return output.target.buffer;
  }

  function handleFiles(files) {
    var list = Array.prototype.slice.call(files || []).filter(Boolean);
    if (!list.length) return;
    var p = Promise.resolve();
    list.forEach(function (f) {
      p = p.then(async function () {
        var kind = await probeFileKind(f);
        if (kind === "video" && !videoFile) { videoFile = f; setLabel("video", f); }
        else if (kind === "audio" && !audioFile) { audioFile = f; setLabel("audio", f); }
      });
    });
    p.then(function () {
      if (videoFile && audioFile) {
        toast("已识别 视频:「" + videoFile.name + "」 音频:「" + audioFile.name + "」");
      } else if (!videoFile) {
        toast("没有识别出视频文件，请再选择一个视频", "warn");
      } else {
        toast("没有识别出音频文件，请再选择一个音频", "warn");
      }
    });
  }

  async function doMerge() {
    if (merging) { toast("已有合并任务进行中，请等待完成", "warn"); return; }
    if (!videoFile || !audioFile) { toast("请先选择视频文件和音频文件", "warn"); return; }
    if (videoFile === audioFile) { toast("视频和音频不能是同一个文件", "warn"); return; }

    merging = true;
    try {
      setProgress(10, "读取视频文件...");
      var vData = new Uint8Array(await videoFile.arrayBuffer());
      setProgress(35, "读取音频文件...");
      var aData = new Uint8Array(await audioFile.arrayBuffer());
      setProgress(55, "合并封装中...");

      var merged;
      try {
        merged = await mergeMediaBuffers(vData, aData);
      } catch (firstError) {
        // 选反了（把音频当成了视频）时自动交换重试
        merged = await mergeMediaBuffers(aData, vData);
      }

      var blob = new Blob([merged], { type: "video/mp4" });
      var url = URL.createObjectURL(blob);
      var name = (videoFile.name || "video").replace(/\.[^.]+$/, "") + "_merged.mp4";
      var a = document.createElement("a");
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 10000);

      setProgress(100, "合并完成，已开始下载");
      toast("合并完成：" + name);
    } catch (error) {
      setProgress(0, "合并失败");
      toast("合并失败：" + ((error && error.message) || error), "err");
    } finally {
      merging = false;
    }
  }

  // ---- 事件绑定 ----
  $("[data-vbtn]").addEventListener("click", function () { $("[data-vinput]").click(); });
  $("[data-abtn]").addEventListener("click", function () { $("[data-ainput]").click(); });
  $("[data-both]").addEventListener("click", function () { $("[data-bothinput]").click(); });
  $("[data-merge]").addEventListener("click", doMerge);

  $("[data-vinput]").addEventListener("change", function (e) {
    videoFile = e.target.files && e.target.files[0] ? e.target.files[0] : null;
    setLabel("video", videoFile);
  });
  $("[data-ainput]").addEventListener("change", function (e) {
    audioFile = e.target.files && e.target.files[0] ? e.target.files[0] : null;
    setLabel("audio", audioFile);
  });
  $("[data-bothinput]").addEventListener("change", function (e) { handleFiles(e.target.files); });

  ["dragenter", "dragover"].forEach(function (evt) {
    document.body.addEventListener(evt, function (e) { e.preventDefault(); $drop.classList.add("over"); });
  });
  ["dragleave", "drop"].forEach(function (evt) {
    document.body.addEventListener(evt, function (e) { e.preventDefault(); $drop.classList.remove("over"); });
  });
  document.body.addEventListener("drop", function (e) {
    handleFiles(e.dataTransfer && e.dataTransfer.files);
  });
})();
